# 🎮 Tic Tac Toe Game  
A simple and interactive **Tic Tac Toe** game built using **HTML, CSS, and JavaScript**.  
Two players can take turns placing **X** and **O** on a 3×3 grid.  
The game detects **wins**, **draws**, and includes a **Reset** button to start a new match.


## 📌 Features
- ✔ Two-player mode  
- ✔ 3×3 responsive grid  
- ✔ Highlights winner (horizontal / vertical / diagonal)  
- ✔ Detects draw condition  
- ✔ Reset button for a new game  
- ✔ Fully responsive UI  
- ✔ Clean and modern design  


## 🚀 Live Demo   
https://shravaniii06.github.io/tic_tac_toe/
