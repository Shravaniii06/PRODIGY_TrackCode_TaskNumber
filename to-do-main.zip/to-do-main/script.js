let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

function addTask() {
  const title = document.getElementById("title").value;
  const desc = document.getElementById("description").value;
  const due = document.getElementById("dueDate").value;
  const priority = document.getElementById("priority").value;

  if (title === "") {
    alert("Please enter task title");
    return;
  }

  const task = {
    id: Date.now(),
    title,
    desc,
    due,
    priority,
    completed: false
  };

  tasks.push(task);
  saveTasks();
  displayTasks();

  document.getElementById("title").value = "";
  document.getElementById("description").value = "";
}

function displayTasks() {
  const list = document.getElementById("taskList");
  list.innerHTML = "";

  tasks.forEach(task => {
    const li = document.createElement("li");
    li.className = "task";

    if (task.completed) li.classList.add("completed");

    li.innerHTML = `
      <strong>${task.title}</strong><br>
      ${task.desc}<br>
      Due: ${task.due || "N/A"} | Priority: ${task.priority}<br>

      <button class="action-btn" onclick="toggleTask(${task.id})">
        ${task.completed ? "Mark Active" : "Mark Completed"}
      </button>
      <button class="action-btn" onclick="editTask(${task.id})">Edit</button>
      <button class="action-btn" onclick="deleteTask(${task.id})">Delete</button>
    `;

    list.appendChild(li);
  });
}

function toggleTask(id) {
  tasks = tasks.map(task =>
    task.id === id ? { ...task, completed: !task.completed } : task
  );
  saveTasks();
  displayTasks();
}

function editTask(id) {
  const task = tasks.find(t => t.id === id);
  const newTitle = prompt("Edit title", task.title);
  if (newTitle !== null) {
    task.title = newTitle;
    saveTasks();
    displayTasks();
  }
}

function deleteTask(id) {
  tasks = tasks.filter(task => task.id !== id);
  saveTasks();
  displayTasks();
}

function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

displayTasks();