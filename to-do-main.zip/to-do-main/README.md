# ✅ To-Do List App

A simple To-Do List web application built using:
- HTML
- CSS
- JavaScript

## Features
- Add tasks
- Delete tasks
- Mark tasks as completed
- Simple & clean UI

## Live Demo
https://shravanilii06.github.io/to-do/
