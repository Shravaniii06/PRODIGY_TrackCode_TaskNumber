# 🧮 Calculator App

## Task-01: Basic Calculator

A simple calculator web app built using *HTML, CSS, and JavaScript* that performs basic arithmetic operations.

### 🚀 Features
- Addition, Subtraction, Multiplication, Division  
- Clear function  
- Responsive UI  

### 🛠 Tech Stack
- HTML  
- CSS  
- JavaScript  

### 🔗 Live Demo  
👉https://shravaniii06.github.io/calculator/

### 📂 Files
- index.html  
- style.css  
- script.js  

### 👩‍💻 Author
*Shravani Dhabekar*

### 📄 Note
Project created for internship/educational purposes.
